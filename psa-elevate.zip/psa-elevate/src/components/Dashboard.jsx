import React, { useState } from "react";
import { useLocation } from "react-router-dom";
import "./styles/Dashboard.css";
import "./styles/Sidebar.css";
import "./styles/CompletedCourses.css";
import "./styles/CVSubmission.css";
import "./styles/RecommendedCourses.css";
import "./styles/RecommendedMentors.css";

const Dashboard = () => {
  const location = useLocation();
  const { loginData } = location.state; // Get the login data passed from HomeLogin

  const [activeSection, setActiveSection] = useState("completed-courses");
  const [cvSubmitted, setCvSubmitted] = useState(false); // Track CV submission status
  const [cvFile, setCvFile] = useState(null); // Track the uploaded file
  const [isLoading, setIsLoading] = useState(false); // Loading state for the overlay
  const [error, setError] = useState(null); // Error state

  // Handle file selection for CV
  const handleFileChange = (e) => {
    setCvFile(e.target.files[0]); // Capture the file selected by the user
    console.log("Selected file:", e.target.files[0]);
  };

  // Handle CV file upload to the backend
  const handleCvSubmit = async (e) => {
    e.preventDefault();

    if (!cvFile) {
      console.log("No file selected.");
      return;
    }

    const formData = new FormData();
    formData.append("username", loginData.userinfo.username); // Add username to formData
    formData.append("cv", cvFile); // Add file to formData

    setIsLoading(true); // Start loading state
    setError(null); // Reset any previous errors

    try {
      // Send the POST request using fetch
      const response = await fetch(
        "http://20b97877.r6.cpolar.cn/api/upload-cv/",
        {
          method: "POST",
          body: formData, // Send FormData containing the username and file
        }
      );

      if (!response.ok) {
        throw new Error("CV upload failed");
      }

      const data = await response.json();
      console.log("CV upload response:", data); // Log the response from the backend
      setCvSubmitted(true); // Mark the CV as submitted
    } catch (error) {
      console.error("CV upload failed:", error); // Handle errors appropriately
      setError(error.message); // Set error state
    } finally {
      setIsLoading(false); // Stop loading regardless of success or failure
    }
  };

  return (
    <div className="dashboard-container">
      {/* Loading overlay */}
      {isLoading && (
        <div className="loading-overlay">
          <div className="spinner">
            {/* You can replace with any loading spinner */}
            <span>Loading...</span>
          </div>
        </div>
      )}

      {/* Sidebar */}
      <div className="sidebar">
        {loginData && (
          <div className="user-info">
            <img
              src="https://i.pravatar.cc/150?img=3"
              alt="User Avatar"
              className="user-avatar"
            />
            <h4>{loginData.userinfo.full_name}</h4>
            <p>
              <strong>Job Title:</strong> {loginData.job_description.job_title}
            </p>
            <p>
              <strong>Email:</strong> {loginData.userinfo.email}
            </p>
          </div>
        )}
        <ul className="navigation">
          <li onClick={() => setActiveSection("completed-courses")}>
            Completed Courses
          </li>
          <li onClick={() => setActiveSection("cv-submission")}>
            CV Submission
          </li>
          <li onClick={() => setActiveSection("recommended-courses")}>
            Recommended Courses
          </li>
          <li onClick={() => setActiveSection("recommended-mentors")}>
            Recommended Mentors
          </li>
        </ul>
      </div>

      {/* Main Content */}
      <div className="content">
        {activeSection === "completed-courses" && (
          <div id="completed-courses" className="section">
            <div className="card completed-courses">
              <div className="card-body">
                <h4 className="card-title">Completed Courses</h4>
                {loginData.completed_courses.length > 0 ? (
                  <ul className="list-group">
                    {loginData.completed_courses.map((course, index) => (
                      <li className="list-group-item" key={index}>
                        {course.course_name}
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p>No completed courses available.</p>
                )}
              </div>
            </div>
          </div>
        )}

        {activeSection === "cv-submission" && (
          <div className="cv-submission">
            <h3>Submit Your CV</h3>
            {!cvSubmitted ? (
              <form onSubmit={handleCvSubmit}>
                <div className="mb-3">
                  <input
                    type="file"
                    className="form-control"
                    accept=".pdf"
                    onChange={handleFileChange}
                  />
                </div>
                <button type="submit" className="btn btn-primary">
                  Submit CV
                </button>
              </form>
            ) : (
              <p>Your CV has been submitted successfully!</p>
            )}
            {error && <div className="error-message">{error}</div>}{" "}
            {/* Display error if any */}
          </div>
        )}

        {activeSection === "recommended-courses" && (
          <div id="recommended-courses" className="section">
            <div className="card recommended-courses">
              <div className="card-body">
                <h4 className="card-title">Recommended Courses</h4>
                {loginData.recommended_courses.length > 0 ? (
                  <ul className="list-group">
                    {loginData.recommended_courses.map((course, index) => (
                      <li className="list-group-item" key={index}>
                        {course.course_name}
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p>No recommended courses available.</p>
                )}
              </div>
            </div>
          </div>
        )}

        {activeSection === "recommended-mentors" && (
          <div id="recommended-mentors" className="section">
            <div className="card recommended-mentors">
              <div className="card-body">
                <h4 className="card-title">Recommended Mentors</h4>
                {loginData.recommended_mentors &&
                loginData.recommended_mentors.length > 0 ? (
                  <ul className="list-group">
                    {loginData.recommended_mentors.map((mentor, index) => (
                      <li className="list-group-item" key={index}>
                        <strong>{mentor.mentor_name}</strong> - Skills:{" "}
                        {mentor.skills.join(", ")} <br />
                        <em>Contact: {mentor.contact_info}</em>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p>No recommended mentors available.</p>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
