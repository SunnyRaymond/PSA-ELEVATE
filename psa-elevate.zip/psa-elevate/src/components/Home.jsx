import React, { useState } from "react";
import { useNavigate } from "react-router-dom"; // Import useNavigate for redirecting
import "./styles/HomeLogin.css"; // Assuming your styles are here

const HomeLogin = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [loginResponse, setLoginResponse] = useState(null);
  const navigate = useNavigate(); // Initialize navigate

  const handleLogin = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch("http://20b97877.r6.cpolar.cn/api/login/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          username: username,
          password: password,
        }),
      });

      if (!response.ok) {
        console.log(response);
        throw new Error("Login failed");
      }

      const data = await response.json();
      setLoginResponse(data);
      setMessage("Login successful");
      console.log("Login Response:", data); // Printing what the backend returns

      // Redirect to the dashboard and pass the login response as state
      navigate("/dashboard", { state: { loginData: data } });
    } catch (error) {
      setMessage("Login failed");
    }
  };

  return (
    <div className="home-login-container">
      <div className="hero-section">
        <div className="overlay"></div>
        <div className="hero-content">
          <h1 className="display-4">Welcome to PSA Elevate</h1>
          <p className="lead">
            Your journey to continuous learning starts here!
          </p>
        </div>
      </div>

      <div className="login-section">
        <div className="card login-card shadow-lg">
          <div className="card-body">
            <h2 className="card-title text-center mb-4">Login</h2>
            <form onSubmit={handleLogin}>
              <div className="mb-3">
                <label className="form-label">Username</label>
                <input
                  type="text"
                  className="form-control"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Enter your username"
                />
              </div>
              <div className="mb-3">
                <label className="form-label">Password</label>
                <input
                  type="password"
                  className="form-control"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                />
              </div>
              <button type="submit" className="btn btn-primary btn-block">
                Login
              </button>
            </form>
            {message && <div className="alert alert-info mt-3">{message}</div>}
            {loginResponse && (
              <div className="mt-4">
                <h5>Login Response</h5>
                <pre>{JSON.stringify(loginResponse, null, 2)}</pre>{" "}
                {/* Displaying the backend response */}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomeLogin;
